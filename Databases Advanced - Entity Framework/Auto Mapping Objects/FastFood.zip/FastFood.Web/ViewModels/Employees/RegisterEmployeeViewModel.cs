﻿namespace FastFood.Web.ViewModels.Employees
{
    public class RegisterEmployeeViewModel
    {
        public string PositionName { get; set; }
    }
}
