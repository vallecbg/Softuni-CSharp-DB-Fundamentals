﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FastFood.Models.Enums
{
    public enum OrderType
    {
        ForHere = 0,
        ToGo = 1
    }
}
