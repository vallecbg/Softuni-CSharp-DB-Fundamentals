﻿namespace SoftJail.Data
{
   public static class Configuration
    {
        public static string ConnectionString = @"Server=.\SQLEXPRESS;Database=SoftJail;Integrated Security=True";
    }
}
